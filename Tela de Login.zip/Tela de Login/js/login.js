 function validateLogin() {
                const users =
                [[admin,123],
                [molisa,12345],
                [putz,alface]];
                var found = false;


                var username = document.getElementById("user").value;
                var password = document.getElementById("pass").value;

                for(var l = 0; l <= 2; l++) {
                    for(var c = 0; c <= 2; c++) {
                        if(username == users[i]) {
                            found = true;
                        } else {
                            found = false;
                        };
                    };
                };
                
                if(found) {
                    alert("Login efetuado com sucesso.")
                } else {
                    alert("Usuário não encontrado.");
                };

                if(username == "" || password == "") {
                    alert("Favor preencher todos os campos.");
                } else {
                    if(isNaN(user)) {
                        alert("Login efetuado com sucesso.")
                    } else {
                        alert("Nome de usuário não pode ser um número.")
                    };
                };
            };